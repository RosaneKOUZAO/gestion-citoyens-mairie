import model.Citoyen;
import model.Mairie;
import vue.FenetreMairie;
import vue.FenetreNomVille;

public class Main {
    public static void main(String[] args) {
        Citoyen.read();
        Mairie mairie = Mairie.read();
        if (mairie == null) {
            new FenetreNomVille(mairie);
        } else {
            new FenetreMairie(mairie);
        }
    }

}
