package model;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Vector;

public class Mairie implements Serializable{
      private  String nomVille;
      private Vector<Citoyen> ListCitoyens;
      private Vector<Décès> ListDec;
      private Vector<Divorce> ListDiv;
      private Vector<Naissance> ListNaissance;
      private Vector<Mariage> ListMarie;


      
    public Mairie(String nomVille) {
    this.nomVille = nomVille;
    ListCitoyens=new Vector<> ();
    ListDec=new Vector<Décès>();
    ListDiv = new Vector<Divorce>();
    ListNaissance = new Vector<Naissance>();
    ListMarie = new Vector<Mariage>();
    }



   public void addCitoyen(Citoyen citoyen){
   //ajouter un citoyen et incrementer l'id 
   Citoyen.incrAllId();
   ListCitoyens.add(citoyen);
   }


    
    public String getNomVille (){
        return nomVille;
    }
    
  public Vector <Citoyen> getListCitoyens() {
        return ListCitoyens;
    }

    public Vector <Décès>  getListDec() {
        return ListDec;
    }



    public Vector <Divorce> getListDiv() {
        return ListDiv;
    }


    public Vector <Naissance>  getListNaissance() {
        return ListNaissance;
    }
public Vector <Mariage>  getListMarie() {
        return ListMarie;
    }



     Citoyen getById(int id){
        //trouver un citoyen dans la mairie a partir de son id
        for(Citoyen citoyen : getListCitoyens()){
         if(citoyen.getId()==id){
             return citoyen;
         }
        }
        return null; 
     }

     public String getInfoById(int id){
    
        Citoyen citoyen=getById(id);
        if(citoyen==null) return "Le citoyen n'est pas inscrit dans la mairie";
        //renvoyer les info de l'id correpondant au citoyen
       return citoyen.toString();
        
     }
    


     public String getAllInfo(){
        //obtenir la chaine de caractere contenant tout les citoyens
        String info="<html>";
        for(Citoyen citoyen : ListCitoyens){
        info+=citoyen.toString();
        info+="<br>";
        }
        info+="</html>";
        return info.equals("<html></html>") ? "aucun citoyen n'est dans la mairie": info;
     }

      void removeCitoyen(int id){
        Vector <Citoyen> citoyen=getListCitoyens();
        for(int i=0;i<citoyen.size();i++){
            if(citoyen.get(i).getId()==id){
            citoyen.remove(i);    
            }
           }  
     }

   
      void removeMariage(int id){
        Vector <Mariage> mariages=getListMarie();
        for(int i=0;i<mariages.size();i++){
            if(mariages.get(i).getEpouse().getId()==id || mariages.get(i).getEpoux().getId()==id){
            mariages.remove(i);    
            }
           }
        
     }

     public void save(){

        //sauvegarder l'objet dans un fichier
     try(FileOutputStream file=new FileOutputStream("data/mairie.ser");
         ObjectOutputStream write=new ObjectOutputStream(file)){
      write.writeObject(this);
     }catch (IOException i){
      
     }
     }
 
     public static Mairie read(){
        Mairie mairie=null;
        
        //reprendre les données du fichier
        try(FileInputStream file=new FileInputStream("data/mairie.ser");
        ObjectInputStream read=new ObjectInputStream(file);){
          mairie=(Mairie) read.readObject();
          return mairie;
        }catch(IOException i){
            return mairie;
         }catch(ClassNotFoundException c){
            return mairie; 

         }
       
     }
}