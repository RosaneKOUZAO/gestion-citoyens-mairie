
package model;

import java.io.Serializable;

public class Décès implements Serializable {
    private Citoyen defunt;
    private Mairie mairie;
    private String dateDeces;

    public Décès(Citoyen defunt , Mairie mairie, String dateDeces) {
        this.dateDeces=dateDeces;
         this.defunt = defunt;
        this.mairie = mairie;
    }
    public String getDateDeces(){
        return dateDeces;
    }
public Citoyen getDefunt() {
        return defunt;
    }

    public Mairie getMairie() {
        return mairie;
    }


    public static String deceder(int id,Mairie mairie,String dateDeces){
     Citoyen citoyen=mairie.getById(id);
     if(citoyen==null) return "Le citoyen n'est pas inscrit dans la mairie";

     //ajout a la liste de deces et supression du citoyen dans les autre listes
     Décès deces=new Décès(citoyen, mairie, dateDeces);
     mairie.getListDec().add(deces);
     mairie.removeMariage(id);
     mairie.removeCitoyen(id);
     citoyen.setActDeces(deces);
     return "le citoyen est considérer comme déceder";
    } 
    

}