package model;
import java.util.Vector;

public class Femme extends Citoyen {
    
    private Vector<Mariage> ListMarie;
    private Vector<Naissance> enfants;

    public Femme(String nom, String prenom, Mairie mairie, String dateNaiss) {
        super(nom, prenom, mairie,dateNaiss); 
        ListMarie=new Vector <Mariage>();  
        enfants=new Vector <Naissance>();
    }

    public String getEtatCivil(){
        Mariage mariage=getLastMariage();
        if(mariage==null) return "célibataire";
        if(mariage.getActDiv()!=null) return "divorcée";
        if(mariage.getEpoux().getActDec()!=null) return "veuve";
        return "mariée";
    }


      public Vector <Mariage> getListMarie() {
        return ListMarie;
    }

    public Vector <Naissance>  getListNaissance() {
        return enfants;
    }

    public Mariage getLastMariage(){
        int size=ListMarie.size()-1;    
        //obtenir le dernier mariage ou null s'il n y en a pas   
        return size>=0 ? ListMarie.get(size) : null;
        }
    

        public Homme getConjoint(){
            Mariage mariage=getLastMariage();
            //renvoyer le conjoint s'il n'est pas déceder ou divorcer
            return (mariage!=null && mariage.getActDiv()==null && mariage.getEpoux().getActDec()==null) ? mariage.getEpoux(): null;
          }


}