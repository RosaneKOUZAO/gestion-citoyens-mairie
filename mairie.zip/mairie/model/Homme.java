package model;
import java.util.Vector;

public class Homme extends Citoyen {

    private Vector<Mariage> ListMarie;
    private Vector<Naissance> enfants;


    public Homme(String nom, String prenom, Mairie mairie,String dateNaiss) {
        super(nom, prenom, mairie,dateNaiss); 
        ListMarie=new Vector <Mariage>();  
        enfants=new Vector <Naissance>();
    }


    public Vector <Mariage> getListMarie() {
        return ListMarie;
    }

    public String getEtatCivil(){
        Mariage mariage=getLastMariage();
        if(mariage==null) return "célibataire";
        if(mariage.getActDiv()!=null) return "divorcé";
        if(mariage.getEpouse().getActDec()!=null) return "veuf";
        return "marié";
    }

    public Vector <Naissance>  getListNaissance() {
        return enfants;
    }

    public Mariage getLastMariage(){
    int size=ListMarie.size()-1; 
    //obtenir le dernier mariage ou null s'il n y en a pas   
    return size>=0 ? ListMarie.get(size) : null;
    }



    public Femme getConjoint(){
      Mariage mariage=getLastMariage();

      return (mariage!=null && mariage.getActDiv()==null && mariage.getEpouse().getActDec()==null) ? mariage.getEpouse(): null;
    }
}