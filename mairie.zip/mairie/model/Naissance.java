package model;

import java.io.Serializable;

public class Naissance implements Serializable{

    private String dateNaiss;
    private Homme pere;
    private Femme mere;
    private Mairie mairie;
    private Citoyen nee;
    
    public Naissance(String dateNaiss,Homme pere, Femme mere,Mairie mairie , Citoyen nee) {
        this.dateNaiss = dateNaiss;
        this.pere = pere;
        this.mere = mere;
        this.mairie = mairie;
        this.nee = nee;
    }

    public String getDateNaiss() {
        return dateNaiss;
    }

    public Homme getPere() {
        return pere;
    }

    public Femme getMere() {
        return mere;
    }

   public Mairie getMairie(){
    return mairie;
   }
   public Citoyen getNee(){
    return nee;
   }



    public static String naitre(int id1, int id2,Mairie mairie, Citoyen nee){
    //verifier les conditions
    Citoyen citoyen1=mairie.getById(id1);
    Citoyen citoyen2=mairie.getById(id2);
    if(citoyen1==null||citoyen2==null) return "Au moins un des citoyens n'est pas inscrit dans la mairie";
    if((citoyen1 instanceof Homme && citoyen2 instanceof Homme) || (citoyen1 instanceof Femme && citoyen2 instanceof Femme)){
     return "Naissance impossible";   
   }

   // detecter le sexe des parent et les assigner à l'enfant
   Naissance naissance;
   if(citoyen1 instanceof Homme){
    naissance=new Naissance(nee.getDateNaiss(), (Homme) citoyen1, (Femme)citoyen2, mairie, nee);
   } else{
    naissance=new Naissance(nee.getDateNaiss(), (Homme) citoyen2, (Femme)citoyen1, mairie, nee);
   }
   
       //enregistrer la naissance dans les autre class
       citoyen1.getListNaissance().add(naissance);
       citoyen2.getListNaissance().add(naissance);
       mairie.getListNaissance().add(naissance);
       mairie.addCitoyen(naissance.getNee());

   return "la naissance à abouti";
  

}
    }
