
package model;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Vector;
   public abstract class Citoyen implements Serializable{

public int id;
    private static int allId;
    protected String nom;
    protected String prenom;
    protected Mairie mairie;
    protected Décès actDec;
    protected Naissance actNais;
    protected String dateNaiss;


    public Citoyen (String nom, String prenom, Mairie mairie,String dateNaiss) {   
        this.dateNaiss=dateNaiss;
        this.id =allId;
        this.nom = nom;
        this.prenom = prenom;
        this.actNais = null;
        this.mairie = mairie;
        this.actDec = null;
    }

     public int getId() {
        return id;
    }

    public String getDateNaiss(){
        return dateNaiss;
    }
    public String getNom() {
        return nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public Naissance  getActNaiss() {
        return actNais;
    }

    public Mairie getMairie (){
        return mairie;
    }
    public Décès getActDec (){
        return actDec;
    }
    public static void incrAllId() {
        allId++;
    }

     void setActDeces (Décès deces){
        actDec=deces;
    }

         public static void save(){
        //sauvegarder l'objet dans un fichier
     try(FileOutputStream file=new FileOutputStream("data/allId.ser");
         ObjectOutputStream write=new ObjectOutputStream(file)){
      write.writeObject(allId);
     }catch (IOException i){
      
     }
     }
 
     public static void read(){
        
        //recharger les données du fichier
        try(FileInputStream file=new FileInputStream("data/allId.ser");
        ObjectInputStream read=new ObjectInputStream(file);){
          allId=(int) read.readObject();
        }catch(IOException i){
            allId=0;
         }catch(ClassNotFoundException c){
            allId=0; 

         }
       
     }

      String to_string(){
        Citoyen conjoint= this.getConjoint();
        //renvoyer les information du this en parametre en String
        return "{id:"+this.getId()+", nom:"+this.getNom()+", prenom:"+this.getPrenom()+ 
        ", sexe:"+(this instanceof Homme ? "homme":"femme")+", date_de_naissance:"+
        this.getDateNaiss()+", etat_civil:"+this.getEtatCivil()+ ", conjoint:("+ (conjoint!=null ? "nom:"+conjoint.getNom()+
        ", prenom:"+conjoint.getPrenom()+")}" : "aucun)}");
     }
    
    public abstract Vector<Mariage> getListMarie();
    public abstract Mariage getLastMariage();
    public abstract Citoyen getConjoint();
    public abstract Vector <Naissance>  getListNaissance();
    public abstract String getEtatCivil();
}