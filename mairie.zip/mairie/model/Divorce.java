package model;

import java.io.Serializable;

public class Divorce implements Serializable{

     private String dateDiv;
    private Mairie mairie;
    private Mariage actMar;



    public Divorce(String dateDiv,Mairie mairie , Mariage actMar) {
 
        this.dateDiv = dateDiv;
        this.mairie = mairie;
        this.actMar = actMar;
    }



public String getDateDiv() {
        return dateDiv;
    }

    public Mairie getMairie() {
        return mairie;
    }

    public Mariage getActMar() {
        return actMar;
    }





     public static String divorcer(int id,Mairie mairie,String dateDiv){
     Citoyen citoyen=mairie.getById(id);
     
     //verifier si le citoyen peut divorcer
     if(citoyen==null) return "Le citoyen n'est pas inscrit dans la mairie";
     Citoyen conjoint=citoyen.getConjoint();
     if(conjoint==null) return "le citoyen n'est pas marié";

     //faire divorcer le couple si les conditions sont valides
     Divorce divorce=new Divorce(dateDiv,mairie,citoyen.getLastMariage());
     citoyen.getLastMariage().setDiv(divorce);
     conjoint.getLastMariage().setDiv(divorce);
     mairie.removeMariage(id);
     mairie.getListDiv().add(divorce);
     return "Citoyens divorcés avec succès";
     }
}