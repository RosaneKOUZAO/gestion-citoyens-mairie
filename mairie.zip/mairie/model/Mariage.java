package model;

import java.io.Serializable;

public class Mariage implements Serializable{
    private String dateMar;
    private Homme epoux;
    private Femme epouse;
    private Mairie mairie;
    private Divorce actDiv;

    public Mariage(String dateMar, Homme epoux , Femme epouse , Mairie mairie , Divorce actDiv) {
        this.dateMar = dateMar;
        this.epoux= epoux;
        this.epouse= epouse;
        this.mairie = mairie;
        this.actDiv = actDiv;
  
    }
       

public String getDateMar() {
        return dateMar;
    }

    public Homme getEpoux() {
        return epoux;
    }

    public Femme getEpouse() {
        return epouse;
    }

    public Mairie  getMairie() {
        return mairie;
    }

    public Divorce getActDiv (){
        return actDiv;
    }


     void setDiv (Divorce div){
        actDiv=div;
    }

     public static String marier(int id1, int id2,Mairie mairie,String dateMar){
       //trouver les citoyen correspondant aux id 
       Citoyen citoyen1=mairie.getById(id1);
       Citoyen citoyen2=mairie.getById(id2);

       //verifier les conditions de mariage      
       if(citoyen1==null||citoyen2==null) return "Au moins un des citoyens n'est pas inscrit dans la mairie";
       if(citoyen1.getConjoint()!=null || citoyen2.getConjoint()!=null) return "Au moins un des citoyen est déjà marié";
       
       if((citoyen1 instanceof Homme && citoyen2 instanceof Homme) || (citoyen1 instanceof Femme && citoyen2 instanceof Femme)){
        return "Mariage impossible";
       }

       //marier les citoyen selon leur sexe
       Mariage mariage;
       if(citoyen1 instanceof Homme){
        mariage=new Mariage(dateMar,(Homme) citoyen1,(Femme) citoyen2,mairie,null);
     } else{
        mariage=new Mariage(dateMar,(Homme) citoyen2,(Femme) citoyen1,mairie,null);
     }

     //enregistrer les naissance dans les autre class
       mairie.getListMarie().add(mariage); 
       citoyen1.getListMarie().add(mariage);
       citoyen2.getListMarie().add(mariage);
       return "les citoyens ont été mariés avec succès";
      
  
     
    
     }
   

}