package vue;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controler.ControlerMariage;
import model.Mairie;

public class FenetreMariage extends JFrame{
    JLabel idLabel1=new JLabel("Id d'une des personne à marier:");
    JTextField idTextField1=new JTextField("saisir l'id d'un citoyen");
    JLabel idLabel2=new JLabel("Id d'une des personne à marier:");
    JTextField idTextField2=new JTextField("saisir l'id d'un citoyen");
    JButton confirmer= new JButton("Confirmer");
    JLabel dateLabel=new JLabel("date de mariage:");
    JTextField dateTextField=new JTextField("saisir une date");
    JLabel message=new JLabel(" ");
    Mairie mairie;

    public FenetreMariage(Mairie mairie){
        JComponent[] idProp={idLabel1,idTextField1,idLabel2,idTextField2,dateLabel,dateTextField};
        JComponent[] citoyenConfirm={confirmer,message};
        JPanel firstLine= new JPanel(new FlowLayout());
      
        JPanel box=new JPanel();
        
        box.setLayout(new BoxLayout(box, BoxLayout.PAGE_AXIS));

        for (JComponent jComponent : idProp) {
            if(jComponent instanceof JTextField){
                jComponent.setPreferredSize(new Dimension(125,18));
            }
         firstLine.add(jComponent);   
        }
        box.add(firstLine);

        for (JComponent jComponent : citoyenConfirm) {
        jComponent.setAlignmentX(JComponent.CENTER_ALIGNMENT);    
        box.add(jComponent);    
        }
         
        new ControlerMariage(idTextField1, idTextField2, message, confirmer, dateTextField, mairie);
        box.setBorder(new EmptyBorder(25,100,25,100));
        getContentPane().add(box);
        pack();
        setVisible(true);
        setResizable(false);
       
    }
    
}