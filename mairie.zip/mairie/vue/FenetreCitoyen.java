package vue;

import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controler.ControlerCitoyen;
import model.Mairie;
public class FenetreCitoyen extends JFrame{

      //initialisation des composant
      private JLabel nomLabel=new JLabel("Nom:");
      private JTextField nomTextField=new JTextField("Saisir le nom");
      private JLabel prenomLabel=new JLabel("Prenom:");
      private JTextField prenomTextField=new JTextField("Saisir le prenom");
      private JLabel sexeLabel=new JLabel("Sexe:");
      private JLabel dateNaissanceLabel=new JLabel("Date de naissance:");
      private JTextField dateNaissanceTextField=new JTextField("Saisir la date de naissance");
      private JComboBox<String> sexeComboBox= new JComboBox<>(new String[]{"Homme","Femme"});
      private JButton confirmer=new JButton("Confirmer");
      private JLabel message= new JLabel(" ");
      private Mairie mairie;
      
public FenetreCitoyen(Mairie mairie){
    JComponent[] citoyenProp={nomLabel,nomTextField,prenomLabel,prenomTextField,dateNaissanceLabel,
        dateNaissanceTextField ,sexeLabel,sexeComboBox};
    JComponent[] citoyenConfirm={confirmer,message};
    this.mairie=mairie;

    //initialisation des conteneur
  //  JPanel grid=new JPanel(new GridLayout(3,1));
    JPanel firstLine= new JPanel(new FlowLayout());
    JPanel box= new JPanel();
    box.setLayout(new BoxLayout(box , BoxLayout.Y_AXIS));

    //ajout des element de la premiere ligne ou figure les choix pour inscrire le citoyen

    for (JComponent jComponent : citoyenProp) {
        if(jComponent instanceof JTextField){
        jComponent.setPreferredSize(new Dimension(100,18));
        }
        firstLine.add(jComponent);  

    }
    box.add(firstLine);

    //ajout de la deuxieme ligne pour confirmer et envoyer un message si le citoyen est inscrit
for (JComponent jComponent : citoyenConfirm) {
    box.add(jComponent);
}
   
    confirmer.setAlignmentX(JComponent.CENTER_ALIGNMENT);
    message.setAlignmentX(JComponent.CENTER_ALIGNMENT);



    //ajout des conteneurs à la fenetre et parametre de la fenetre

  
    box.setBorder(new EmptyBorder(35,50,10,50));
    getContentPane().add(box);
    pack();
    setResizable(false);
    setVisible(true);

    new ControlerCitoyen(nomTextField, prenomTextField, dateNaissanceTextField, sexeComboBox, confirmer, message,this.mairie);
}
}
