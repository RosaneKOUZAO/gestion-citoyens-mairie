package vue;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controler.ControlerNomVille;
import model.Mairie;

public class FenetreNomVille extends JFrame {
     private JLabel mairieLabel=new JLabel("Nom de ville:");   
 private JTextField mairieTextField= new JTextField("saisir le nom de la ville");
 private JButton confirmer=new JButton("Confirmer");
  private Mairie mairie;



  public FenetreNomVille(Mairie mairie){
    this.mairie=mairie;

    //initialisation des variables
    JComponent[] mairieProp={mairieLabel,mairieTextField};
    JPanel firstLine= new JPanel(new FlowLayout());
    JPanel gridBag= new JPanel(new GridBagLayout());
    GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets=new Insets(0, 0, 5, 0);
        constraints.gridx=0;
        constraints.gridy=0;
        constraints.fill = GridBagConstraints.NONE;


    //ajout des element aux conteneurs
    for (JComponent jComponent : mairieProp) {
        firstLine.add(jComponent);
        if(jComponent instanceof JTextField){
        jComponent.setPreferredSize(new Dimension(125,18));
        }

    }
    gridBag.add(firstLine,constraints);
    constraints.gridy++;
    gridBag.add(confirmer,constraints);

    gridBag.setBorder(new EmptyBorder(40, 100, 10, 100));
    getContentPane().add(gridBag);
    pack();
    setVisible(true);
    setResizable(false);
    new ControlerNomVille(this);
  }


  public JButton getConfirmer(){
    return confirmer;
  }

  public JTextField getMairieTextField(){
    return mairieTextField;
  }
  public Mairie getMairie(){
    return mairie;
  }

  public void setMairie(Mairie mairie){
    this.mairie=mairie;
  }



}
