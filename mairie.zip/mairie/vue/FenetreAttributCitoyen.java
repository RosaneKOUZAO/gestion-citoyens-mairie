package vue;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controler.ControlerAttributCitoyen;
import model.Mairie;

public class FenetreAttributCitoyen extends JFrame {

    private JLabel idLabel = new JLabel("Id du citoyen:");
    private JTextField idTextField = new JTextField("saisir l'id citoyen");
    private JButton confirmer = new JButton("Confirmer");
    private JLabel message = new JLabel(" ");
    private Mairie mairie;

    public FenetreAttributCitoyen(Mairie mairie) {
        this.mairie = mairie;

        // initialisation des variables
        JComponent[] idProp = { idLabel, idTextField };
        JComponent[] idConfirm = { confirmer, message };
        JPanel firstLine = new JPanel(new FlowLayout());
        JPanel gridBag = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.insets = new Insets(0, 0, 5, 0);
        constraints.gridx = 0;
        constraints.gridy = 0;
        constraints.fill = GridBagConstraints.NONE;

        // ajout des element aux conteneurs
        for (JComponent jComponent : idProp) {
            firstLine.add(jComponent);
            if (jComponent instanceof JTextField) {
                jComponent.setMinimumSize(new Dimension(100, 18));
                jComponent.setPreferredSize(new Dimension(100, 18));
            }

        }

        gridBag.add(firstLine, constraints);

        for (JComponent jComponent : idConfirm) {
            constraints.gridy++;
            gridBag.add(jComponent, constraints);
        }

        getContentPane().add(gridBag);
        gridBag.setBorder(new EmptyBorder(40, 100, 10, 100));

        pack();
        setVisible(true);
        new ControlerAttributCitoyen(idTextField, confirmer, message, this.mairie);
    }
}