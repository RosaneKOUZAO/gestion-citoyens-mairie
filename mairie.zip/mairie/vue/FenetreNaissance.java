package vue;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controler.ControlerNaissance;
import model.Mairie;

public class FenetreNaissance extends JFrame {
      private JLabel nomLabel=new JLabel("Nom:");
      private JTextField nomTextField=new JTextField("Saisir le nom");
      private JLabel prenomLabel=new JLabel("Prenom:");
      private JTextField prenomTextField=new JTextField("Saisir le prenom");
      private JLabel sexeLabel=new JLabel("Sexe:");
      private JLabel dateNaissanceLabel=new JLabel("Date de naissance:");
      private JTextField dateNaissanceTextField=new JTextField("Saisir la date de naissance");
      private JComboBox<String> sexeComboBox= new JComboBox<>(new String[]{"Homme","Femme"});
      private JButton confirmer=new JButton("Confirmer");
      private JLabel message= new JLabel(" ");
      private JLabel idLabel1=new JLabel("Id d'un parent:");
      private JTextField idTextField1=new JTextField(" saisir un id");
      private JLabel idLabel2=new JLabel("Id d'un parent:");
      private JTextField idTextField2=new JTextField(" Saisir un id");
      private Mairie mairie;

      public FenetreNaissance(Mairie mairie){
        JComponent[] citoyenProp={nomLabel,nomTextField,prenomLabel,prenomTextField,dateNaissanceLabel,
        dateNaissanceTextField ,sexeLabel,sexeComboBox};
        JComponent[] parentProp={idLabel1,idTextField1,idLabel2,idTextField2};
        JComponent[] naissanceConfirme={confirmer,message};
        this.mairie=mairie;

        JPanel box=new JPanel(new GridBagLayout());
        //box.setLayout(new BoxLayout(box,BoxLayout.PAGE_AXIS));
        JPanel firstLine=new JPanel(new FlowLayout());
        JPanel secondLine=new JPanel(new FlowLayout());
        GridBagConstraints constraints=new GridBagConstraints();
        constraints.gridx=0;
        constraints.gridy=0;
        constraints.anchor = GridBagConstraints.WEST;
        for (JComponent jComponent : citoyenProp) {
            firstLine.add(jComponent);
     
        }
   
        box.add(firstLine,constraints);
        constraints.gridy++;

        for (JComponent jComponent : parentProp) {
            secondLine.add(jComponent);
            if(jComponent instanceof JTextField){
                jComponent.setPreferredSize(new Dimension(125,18));
            }
        }
        box.add(secondLine,constraints);

        constraints.anchor=GridBagConstraints.CENTER;
        for (JComponent jComponent : naissanceConfirme) {
            constraints.gridy++;
            box.add(jComponent,constraints);
       
        }
        
        box.setBorder(new EmptyBorder(25,100,25,100));
        getContentPane().add(box);
        pack();
        setVisible(true);
        setResizable(false);
        new ControlerNaissance(nomTextField, prenomTextField, dateNaissanceTextField, sexeComboBox, confirmer,
         message, idTextField1, idTextField2, this.mairie);

      }
}


