package vue;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import controler.ControlerMairie;
import model.Mairie;

public class FenetreMairie extends JFrame {
    
    //initialisation variable
    private JButton citoyen = new JButton("Ajouter un citoyen");
    private JButton deces = new JButton("Enregistrer un décès");
    private JButton mariage = new JButton("Enregistrer un mariage");
    private JButton divorce = new JButton("Enregistrer un divorce");
    private JButton naissance = new JButton("Enregistrer une naissance");
    private JButton attributCitoyen = new JButton("Obtenir l'état d'un citoyen");
    private JButton attributListCitoyen = new JButton("Obtenir l'état de tous les citoyen");
    private JButton exit = new JButton("Fermer le programme");
    private JButton[] buttons = { citoyen, deces, divorce, naissance, mariage,attributCitoyen,attributListCitoyen,exit};
    Mairie mairie;
    public FenetreMairie(Mairie mairie) {

        this.mairie=mairie;
        JPanel gridBag = new JPanel(new GridBagLayout());
        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.insets = new Insets(0, 0, 10, 0);

        for (int i = 0; i < buttons.length; i++) {
            constraints.gridx = 0;
            constraints.gridy = i;
            buttons[i].setPreferredSize(new Dimension(250, 30));
            gridBag.add(buttons[i], constraints);
        }

        gridBag.setBorder(new EmptyBorder(40, 50, 40, 50));

        getContentPane().add(gridBag);
        setVisible(true);
        pack();
        new ControlerMairie(citoyen, deces, divorce, naissance,attributCitoyen,attributListCitoyen,mariage,exit,this,mairie);
    }

}
