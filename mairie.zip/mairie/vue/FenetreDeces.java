package vue;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import controler.ControlerDeces;
import model.Mairie;

public class FenetreDeces extends JFrame{

//initialisation des composant    
private JLabel citoyenLabel=new JLabel("Citoyen à considérer comme décéder:");
private JTextField citoyenTextField=new JTextField("Saisir l'id du citoyen");
private JButton confirmer= new JButton("Confirmer");
private JLabel dateLabel=new JLabel("Date de décès");
private JTextField dateTextField=new JTextField("Saisir la date de décès");
private JLabel message= new JLabel(" ");
private Mairie mairie;



public FenetreDeces(Mairie mairie){
    JComponent[] citoyenProp={citoyenLabel,citoyenTextField,dateLabel,dateTextField};
    JComponent[] citoyenConfirm={confirmer,message};
    this.mairie=mairie;

    //initialisation des conteneurs
     JPanel firstLine=new JPanel(new FlowLayout());
     JPanel box=new JPanel();
   box.setLayout(new BoxLayout(box,BoxLayout.Y_AXIS));

     //ajout des composant au conteneur
for(JComponent jComponent : citoyenProp){
    if(jComponent instanceof JTextField){
        jComponent.setPreferredSize(new Dimension(125,18));
        }

firstLine.add(jComponent);
firstLine.setBorder(new EmptyBorder(0,0,5,0));
}
box.add(firstLine); 

for (JComponent jComponent : citoyenConfirm) {
    jComponent.setAlignmentX(JComponent.CENTER_ALIGNMENT);
   box.add(jComponent);
}


box.setBorder(new EmptyBorder(25,25,25,25));
//ajout des element sur la fenetre et parametrage de la fenetre
new ControlerDeces(citoyenTextField, confirmer, dateTextField, message, this.mairie);
getContentPane().add(box);
pack();
setResizable(false);
setVisible(true);
}





}