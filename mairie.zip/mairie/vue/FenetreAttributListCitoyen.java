package vue;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;

import controler.ControlerAttributListCitoyen;
import model.Mairie;

public class FenetreAttributListCitoyen extends JFrame{

JButton affiche= new JButton("afficher tout les citoyens");
JLabel message= new JLabel(" ");
Mairie mairie;

public FenetreAttributListCitoyen(Mairie mairie){
    //setLayout(new BorderLayout());
    this.mairie=mairie; 
    JComponent[] element={affiche,message};
    JPanel gridbag=new JPanel(new GridBagLayout());
    GridBagConstraints constraints = new GridBagConstraints();
    constraints.gridx=0;
    constraints.gridy=0;
JScrollPane scrollPane = new JScrollPane(gridbag);
scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
    for (JComponent jComponent : element) {
        gridbag.add(jComponent,constraints);
        constraints.gridy++;
    }
    gridbag.setBorder(new EmptyBorder(25,50,25,50));
    getContentPane().add(scrollPane);
    pack();
    setVisible(true);
    
    new ControlerAttributListCitoyen(affiche, message, mairie);
}
}