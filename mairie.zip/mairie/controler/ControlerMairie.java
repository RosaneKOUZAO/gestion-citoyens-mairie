package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

import model.Citoyen;
import model.Mairie;
import vue.FenetreAttributCitoyen;
import vue.FenetreAttributListCitoyen;
import vue.FenetreCitoyen;
import vue.FenetreDeces;
import vue.FenetreDivorce;
import vue.FenetreMairie;
import vue.FenetreMariage;
import vue.FenetreNaissance;

public class ControlerMairie implements ActionListener{
    private JButton citoyen;
    private JButton deces;
    private JButton divorce;
    private JButton mariage; 
    private JButton naissance; 
    private JButton exit; 
    private Mairie mairie;
    private JButton attributCitoyen;
    private JButton attributListCitoyen;
    private FenetreMairie fenetre;
    
    public ControlerMairie(JButton citoyen, JButton deces, JButton divorce,JButton naissance,
    JButton attributCitoyen,JButton attributListCitoyen,JButton mariage, JButton exit , FenetreMairie fenetre,Mairie mairie  ){
    this.fenetre=fenetre;
    this.mairie=mairie;
    this.citoyen=citoyen;
    this.divorce=divorce;
    this.naissance=naissance;
    this.deces=deces;
    this.exit=exit;
    this.mariage=mariage;
    this.attributCitoyen=attributCitoyen;
    this.attributListCitoyen=attributListCitoyen;
    this.citoyen.addActionListener(this);
    this.deces.addActionListener(this);
    this.divorce.addActionListener(this);
    this.exit.addActionListener(this);
    this.naissance.addActionListener(this);
    this.attributListCitoyen.addActionListener(this);
    this.attributCitoyen.addActionListener(this);
    this.mariage.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){
    //ouvrir les fenetre en fonction du boutton appuyé
    if(e.getSource()==citoyen){
    new FenetreCitoyen(mairie);
    }
    if(e.getSource()==deces){
        new FenetreDeces(mairie);
    }
    if(e.getSource()==divorce){
        new FenetreDivorce(mairie);
    }
    if(e.getSource()==attributCitoyen){
       new FenetreAttributCitoyen(mairie);
    }
    if(e.getSource()==attributListCitoyen){
        new FenetreAttributListCitoyen(mairie);
     }
     if(e.getSource()==exit){
    //fermer le programme en sauvegardant  
     mairie.save();
     Citoyen.save();
     fenetre.dispose();;
     }
     if(e.getSource()==mariage){
      new FenetreMariage(mairie);
     }
     if(e.getSource()==naissance){
      new FenetreNaissance(mairie);
     }
     


}
}