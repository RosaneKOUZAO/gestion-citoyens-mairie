package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import model.Mairie;
import vue.FenetreMairie;
import vue.FenetreNomVille;

public class ControlerNomVille implements ActionListener {

    private FenetreNomVille fenetre;
    public ControlerNomVille(FenetreNomVille fenetre){
    this.fenetre=fenetre;
    fenetre.getConfirmer().addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){
    //creer la mairie, fermer la page du choix du nom et ouverture de la fenetre de mairie    
    fenetre.setMairie(new Mairie(fenetre.getMairieTextField().getText()));
    fenetre.dispose();
    new FenetreMairie(fenetre.getMairie());
    }
} 
