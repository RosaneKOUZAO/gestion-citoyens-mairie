package controler;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import model.Décès;
import model.Mairie;

public class ControlerDeces implements ActionListener {
    private JTextField citoyenTextField;
    private JButton confirmer;
    private Mairie mairie;
    private JTextField dateTextField;
    private JLabel message;

    public ControlerDeces(JTextField citoyenTextField, JButton confirmer,JTextField dateTextField,
     JLabel message, Mairie mairie){
this.citoyenTextField=citoyenTextField;
this.confirmer=confirmer;
this.mairie=mairie;
this.dateTextField=dateTextField;
this.message=message;
this.confirmer.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){
        try {
            //considerer le citoyen comme deceder si la saisi de l'id est bien un nombre entier
            int id=Integer.parseInt(citoyenTextField.getText());
            message.setText(Décès.deceder(id, mairie, dateTextField.getText()));

        } catch (NumberFormatException exception) {
           //mettre un message d'erreur si ce n'est pas un entier 
           message.setText("L'id entré n'est pas un nombre entier");
           
        }
    
    }

    

}
