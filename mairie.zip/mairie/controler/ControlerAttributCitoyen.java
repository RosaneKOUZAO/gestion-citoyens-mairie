package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import model.Mairie;

public class ControlerAttributCitoyen implements ActionListener { 
 private JTextField idTextField;
 private JButton confirmer;
 private JLabel message;
 private Mairie mairie;
 
 public ControlerAttributCitoyen(JTextField idTextField,JButton confirmer, JLabel message,Mairie mairie  ){
    this.idTextField=idTextField;
    this.confirmer=confirmer;
    this.message=message;
    this.mairie=mairie;
    this.confirmer.addActionListener(this);
 }
 public void actionPerformed(ActionEvent e) {
  try {
            //considerer le citoyen comme deceder si la saisi de l'id est bien un nombre entier
            int id=Integer.parseInt(idTextField.getText());
            message.setText(mairie.getInfoById(id));
            
        } catch (NumberFormatException exception) {
           //mettre un message d'erreur si ce n'est pas un entier 
           message.setText("L'id entré n'est pas un nombre entier");
           
        }
 }
}
