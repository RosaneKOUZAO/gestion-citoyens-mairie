package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import model.Mairie;
import model.Mariage;

public class ControlerMariage implements ActionListener {
    private JTextField idTextField1;
    private JTextField idTextField2;
    private JTextField dateTextField;
    private JLabel message;
    private JButton confirmer;
    private Mairie mairie;

    public ControlerMariage(JTextField idTextField1,JTextField idTextField2,
    JLabel message, JButton confirmer,JTextField dateTextField, Mairie mairie){
    this.idTextField1=idTextField1;
    this.idTextField2=idTextField2;
    this.dateTextField=dateTextField;
    this.confirmer=confirmer;
    this.message=message;
    this.mairie=mairie;
    this.confirmer.addActionListener(this);  
    }

    public void actionPerformed(ActionEvent e){
            try {
            //considerer le citoyen comme marier si la saisi de l'id est bien un nombre entier
            int id1=Integer.parseInt(idTextField1.getText());
            int id2=Integer.parseInt(idTextField2.getText());   
            message.setText(Mariage.marier(id1, id2, mairie,dateTextField.getText() ));

        } catch (NumberFormatException exception) {
           //mettre un message d'erreur si ce n'est pas un entier 
           message.setText("Au moins un des id entré n'est pas un nombre entier");
           
        }
      
    }
    
}
