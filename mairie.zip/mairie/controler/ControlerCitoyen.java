package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;

import model.Femme;
import model.Homme;
import model.Mairie;

public class ControlerCitoyen implements ActionListener {
    private JTextField nom;
    private JTextField prenom;
    private JTextField dateNaissance;
    private JComboBox<String> sexe;
    private JLabel message;
    private JButton confirmer;
    private Mairie mairie;

public ControlerCitoyen(JTextField nom,JTextField prenom, JTextField dateNaissance
,JComboBox<String> sexe,JButton confirmer,JLabel message, Mairie mairie){
    this.nom=nom;
    this.prenom=prenom;
    this.dateNaissance=dateNaissance;
    this.sexe=sexe;
    this.confirmer=confirmer;
    this.message=message;
    this.mairie=mairie;
    this.confirmer.addActionListener(this);
}

    public void actionPerformed(ActionEvent e) {
    
    //ajouter un citoyen et mettre un message de confirmation    
    if(sexe.getSelectedItem()=="Homme"){
        Homme citoyen=new Homme(nom.getText(),prenom.getText(),mairie,dateNaissance.getText());
        mairie.addCitoyen(citoyen);
        message.setText("Citoyen ajouté avec succès");
    } else{
        Femme citoyen=new Femme(nom.getText(),prenom.getText(),mairie,dateNaissance.getText());
       mairie.addCitoyen(citoyen);
       message.setText("Citoyen ajouté avec succès");
    }

    
}
}