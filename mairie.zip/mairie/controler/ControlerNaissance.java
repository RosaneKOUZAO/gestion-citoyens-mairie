package controler;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JTextField;

import model.Femme;
import model.Homme;
import model.Mairie;
import model.Naissance;

public class ControlerNaissance implements ActionListener {
    private JTextField nom;
    private JTextField prenom;
    private JTextField dateTextField;
    private JComboBox<String> sexe;
    private JLabel message;
    private JButton confirmer;
    private Mairie mairie;
    private JTextField idTextField1;
    private JTextField idTextField2;

    public ControlerNaissance(JTextField nom,JTextField prenom, JTextField dateTextField
    ,JComboBox<String> sexe,JButton confirmer,JLabel message, JTextField idTextField1
    ,JTextField idTextField2, Mairie mairie){
    this.nom=nom;
    this.prenom=prenom;
    this.dateTextField=dateTextField;
    this.sexe=sexe;
    this.confirmer=confirmer;
    this.message=message;
    this.mairie=mairie;
    this.idTextField1=idTextField1;
    this.idTextField2=idTextField2;
    this.confirmer.addActionListener(this);
    }

    public void actionPerformed(ActionEvent e){

    if(sexe.getSelectedItem()=="Homme"){
            try {
            //considerer le citoyen comme marier si la saisi de l'id est bien un nombre entier
            int id1=Integer.parseInt(idTextField1.getText());
            int id2=Integer.parseInt(idTextField2.getText());   
            Homme citoyen=new Homme(nom.getText(),prenom.getText(),mairie,dateTextField.getText());
            message.setText(Naissance.naitre(id1, id2, mairie, citoyen));

        } catch (NumberFormatException exception) {
           //mettre un message d'erreur si ce n'est pas un entier 
           message.setText("Au moins un des id entré n'est pas un nombre entier");
           
        }
    } else{
       

        try {
            //considerer le citoyen comme marier si la saisi de l'id est bien un nombre entier
            int id1=Integer.parseInt(idTextField1.getText());
            int id2=Integer.parseInt(idTextField2.getText());   
            Femme citoyen=new Femme(nom.getText(),prenom.getText(),mairie,dateTextField.getText());
            message.setText(Naissance.naitre(id1, id2, mairie, citoyen));

        } catch (NumberFormatException exception) {
           //mettre un message d'erreur si ce n'est pas un entier 
           message.setText("Au moins un des id entré n'est pas un nombre entier");
           
        }
    }
    }

}
