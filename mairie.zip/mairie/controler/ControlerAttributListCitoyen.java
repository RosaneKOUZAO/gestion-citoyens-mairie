package controler;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;

import model.Mairie;

public class ControlerAttributListCitoyen implements ActionListener{
JButton affiche;
JLabel message;
Mairie mairie;   

public ControlerAttributListCitoyen(JButton affiche, JLabel message, Mairie mairie){
this.mairie=mairie;
this.message=message;
this.affiche=affiche;
affiche.addActionListener(this);
}

public void actionPerformed(ActionEvent e) {
//afficher le message    
message.setText(mairie.getAllInfo());
 }
}



